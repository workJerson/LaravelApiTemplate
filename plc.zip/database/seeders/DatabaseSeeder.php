<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(HubLocalSeeder::class);
        $this->call(ProgramLocalSeeder::class);
        $this->call(CourseLocalSeeder::class);
        $this->call(SchoolLocalSeeder::class);
        $this->call(GroupSeeder::class);
    }
}
